import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class trans {

    // Mapper Class cho trans240_1.txt và trans240_2.txt
    public static class TransactionMapper extends Mapper<Object, Text, Text, Text> {
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] fields = value.toString().split(",");
            if (fields.length > 1) {
                // Lấy tháng từ trường ngày
                String date = fields[1];
                String month = date.split("-")[0]; // Lấy tháng từ định dạng ngày

                // Lấy Cust ID
                String custID = fields[2];

                // Gửi cặp giá trị (Tháng, CustID)
                context.write(new Text(month), new Text(custID));
            }
        }
    }

    // Reducer Class
    public static class TransactionReducer extends Reducer<Text, Text, Text, Text> {

        private HashMap<String, String> custMap = new HashMap<>();

        // Phương thức setup để tải dữ liệu từ file cust.txt vào trong HashMap
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            Path[] files = context.getLocalCacheFiles();
            for (Path file : files) {
                if (file.getName().equals("cust.txt")) {
                    BufferedReader reader = new BufferedReader(new FileReader(file.toString()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] fields = line.split(",");
                        if (fields.length == 5) {
                            String custID = fields[0];
                            String firstName = fields[1];
                            custMap.put(custID, firstName); // Ánh xạ CustID -> FirstName
                        }
                    }
                    reader.close();
                }
            }
        }

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            HashMap<String, Integer> userCount = new HashMap<>();

            // Đếm số lượng giao dịch cho từng Cust ID
            for (Text value : values) {
                String custID = value.toString();

                // Kiểm tra nếu Cust ID đã tồn tại trong HashMap hay chưa
                if (userCount.containsKey(custID)) {
                    // Nếu có, tăng giá trị đếm thêm 1
                    userCount.put(custID, userCount.get(custID) + 1);
                } else {
                    // Nếu chưa có, khởi tạo giá trị là 1
                    userCount.put(custID, 1);
                }
            }

            // Xây dựng kết quả cuối cùng
            StringBuilder result = new StringBuilder();
            for (String custID : userCount.keySet()) {
                String firstName = custMap.get(custID);
                result.append(firstName).append("-").append(userCount.get(custID)).append(" ");
            }

            // Gửi ra kết quả (Tháng, Danh sách người dùng và số lượng giao dịch)
            context.write(key, new Text(result.toString()));
        }
    }

    // Main method để cấu hình và chạy job
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "transaction count");

        job.setJarByClass(trans.class);

        // Định nghĩa Mapper cho mỗi file input
        MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class, TransactionMapper.class); // trans240_1.txt
        MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class, TransactionMapper.class); // trans240_2.txt

        job.setReducerClass(TransactionReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        // Tải file cust.txt vào bộ nhớ đệm
        job.addCacheFile(new Path(args[2]).toUri()); // Đường dẫn tới cust.txt

        // Thiết lập đường dẫn đầu ra
        FileOutputFormat.setOutputPath(job, new Path(args[3]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
